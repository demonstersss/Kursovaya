# Russian Passport Detection > 153 labeled - Trained Model
https://universe.roboflow.com/eman-qeoog/russian-passport-detection

Provided by a Roboflow user
License: CC BY 4.0

